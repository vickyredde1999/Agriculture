package cropdeal.casestudy.farmer;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.CrossOrigin;



import cropdeal.casestudy.farmer.Models.AuthRequest;
import cropdeal.casestudy.farmer.Models.Farmer;
import cropdeal.casestudy.farmer.Repo.FarmerRepo;

//import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@EnableEurekaClient
//@EnableSwagger2
//(origins = "http://localhost:4200")
public class FarmerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerApplication.class, args);
		
	}

}
