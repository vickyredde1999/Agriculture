package cropdeal.casestudy.farmer.Repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropdeal.casestudy.farmer.Models.AuthRequest;
import cropdeal.casestudy.farmer.Models.Farmer;

public interface FarmerRepo extends MongoRepository<Farmer, Integer>{ 
	  Farmer findByUserName(String username);


	

}
