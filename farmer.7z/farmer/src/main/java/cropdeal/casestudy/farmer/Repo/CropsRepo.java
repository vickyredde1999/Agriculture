package cropdeal.casestudy.farmer.Repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropdeal.casestudy.farmer.Models.Crops;

public interface CropsRepo extends MongoRepository<Crops, Integer>{
	
}


