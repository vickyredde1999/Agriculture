package cropdeal.casestudy.farmer.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cropdeal.casestudy.farmer.Models.Crops;
import cropdeal.casestudy.farmer.Models.Farmer;

import cropdeal.casestudy.farmer.Repo.FarmerRepo;



@Service

public class FarmerService {

	
	@Autowired
    FarmerRepo farmerRepository;
	
	
	
	// getting all farmer record by using the method findaAll() of CrudRepository
	public List<Farmer> getAllFarmer() {
		return farmerRepository.findAll();
	}

	// getting a specific record by using the method findById() of CrudRepository
	public  Farmer getFarmerById(int id) {
		return farmerRepository.findById(id).get();
	}

	// saving a specific record by using the method save() of CrudRepository
	public void saveOrUpdate(Farmer farmer) {
		farmerRepository.save(farmer);
	}

	// deleting a specific record by using the method deleteById() of CrudRepository
	public void delete(int id) {
		farmerRepository.deleteById(id);
	}

	// updating a record
	public void update(Farmer farmer, int farmerId) {
		farmerRepository.save(farmer);
	}
}