package cropdeal.casestudy.farmer.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import cropdeal.casestudy.farmer.Models.Farmer;
import cropdeal.casestudy.farmer.Repo.FarmerRepo;

import java.util.ArrayList;

@Service
public class CustomFarmerDetailService implements UserDetailsService {
    @Autowired
    private FarmerRepo repository;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        Farmer farmer = repository.findByUserName(userName);
        return new org.springframework.security.core.userdetails.User("suhas", "suhas123", new ArrayList<>());
    }
}
