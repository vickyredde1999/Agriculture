package cropdeal.casestudy.farmer.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cropdeal.casestudy.farmer.Models.Crops;
import cropdeal.casestudy.farmer.Repo.CropsRepo;



@Service

public class CropService {
	@Autowired
	CropsRepo cropRepository;

	// getting all crop record by using the method findaAll() of CrudRepository
	public List<Crops> getAllCrops() {
		return cropRepository.findAll();
	}

	// getting a specific record by using the method findById() of CrudRepository
	public  Crops getCropById(int id) {
		return cropRepository.findById(id).get();
	}

	// saving a specific record by using the method save() of CrudRepository
	public void saveOrUpdate(Crops crop) {
		cropRepository.save(crop);
	}

	// deleting a specific record by using the method deleteById() of CrudRepository
	public void delete(int id) {
		cropRepository.deleteById(id);
	}

	// updating a record
	public void update(Crops crop, int cropId) {
		cropRepository.save(crop);
	}
}