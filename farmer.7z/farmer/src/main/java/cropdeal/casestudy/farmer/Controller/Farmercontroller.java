package cropdeal.casestudy.farmer.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cropdeal.casestudy.farmer.Models.Crops;
import cropdeal.casestudy.farmer.Models.Farmer;
import cropdeal.casestudy.farmer.Repo.FarmerRepo;

import cropdeal.casestudy.farmer.service.FarmerService;



@RestController
@RequestMapping("/agriculture")
public class Farmercontroller {
   
	@Autowired
   FarmerRepo repo;
	
	@Autowired
	FarmerService farmerService;
   
	
	// GET mapping
		@GetMapping("/farmer")
		private List<Farmer> getAllFarmer() {
			return farmerService.getAllFarmer();
		}
		
		//Get mapping
   @GetMapping("/getFarmer/{farmerid}")
   public Farmer getFarmerProfileById(@PathVariable("farmerid") int farmerid){
	   return farmerService.getFarmerById(farmerid);
   }
   
   //post mapping
   @PostMapping("/saveProfile")
	   public void saveProfile(@RequestBody Farmer farmer) {
	   farmerService.saveOrUpdate(farmer);
	   }
   
   //put mapping
   @PutMapping("/updateProfile/{farmerid}")
   public void updateFarmer(@PathVariable("farmerid") int farmerid,@RequestBody Farmer farmer) {
	   farmerService.saveOrUpdate(farmer);
   }
// DELETE mapping
	@DeleteMapping("/deleteFarmer{farmerId}")
	private void deleteCrop(@PathVariable("farmerId") int farmerId) {
		farmerService.delete(farmerId);
	}
   
   
}
