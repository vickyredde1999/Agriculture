package com.example.order.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.model.OrderDetails;
import com.example.order.repository.Orderrepo;


@RestController
@RequestMapping("/orders")
public class Controller {
	@Autowired
    private Orderrepo repo;

    @GetMapping("/orders")
    public List<OrderDetails> allOrders()
    {
        List<OrderDetails> list=new ArrayList<>();
        Iterator<OrderDetails> it=repo.findAll().iterator();
        while(it.hasNext()) {
            list.add(it.next());
        }
        return list;

    }
    @GetMapping("/orders/{id}")
    public OrderDetails getOrders(@PathVariable String id) {
        return repo.findById(id).get();
    }
    @PostMapping("/addorder")
    public void addCustomer(@RequestBody OrderDetails orders) {
        repo.save(orders);
    }
    //To find all the completed orders
    @GetMapping("/findCompleted")
    public List<OrderDetails> getCompletedOrders(){
         return repo.findAll().stream().filter(x -> x.getStatus().contains("Completed")).collect(Collectors.toList());
    }
    //To find all the pending orders
    @GetMapping("/findPending")
    public List<OrderDetails> getPendingOrders(){
        return repo.findAll().stream().filter(x -> x.getStatus().contains("Pending")).collect(Collectors.toList());
    }
}
